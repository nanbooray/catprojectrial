package com.catproject.trial;

//import java.util.Random;

import com.almasb.fxgl.animation.Interpolators;
import com.almasb.fxgl.app.GameApplication;
import com.almasb.fxgl.app.GameSettings;
import com.almasb.fxgl.physics.BoundingShape;
import com.almasb.fxgl.physics.HitBox;
import com.almasb.fxgl.entity.Entity;
/* import com.almasb.fxgl.texture.Texture;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty; */
import javafx.scene.Group;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Map;

import static com.almasb.fxgl.dsl.FXGL.*;
import static com.catproject.trial.EntityType.PLAYER;
import static com.catproject.trial.EntityType.WALL;

public class trial1 extends GameApplication {

/*    private IntegerProperty score = new SimpleIntegerProperty();
    private BooleanProperty running = new SimpleBooleanProperty();
    private Random random = new Random();
    private Texture plane;
*/
    private PlayerComponent playerComponent;
    private boolean requestNewGame = false;

    @Override
    protected void initSettings(GameSettings gameSettings) {
        gameSettings.setTitle("Flappy Plane");
        gameSettings.setVersion("1.0");         // default value for height(600) and width(800)
    }

    @Override
    protected void initGame(){
        initBackground();
        initPlayer();
    }

    @Override
    protected void onUpdate(double tpf){
        inc("score", +1);       // increment score value by 1

        if(geti("score") == 3000){
            showGameOver();
        }
        if(requestNewGame){
            requestNewGame = false;
            getGameController().startNewGame();
        }
    }

    private void initBackground(){
        Rectangle rect = new Rectangle(getAppWidth(), getAppHeight(), Color.WHITE);

        Entity bg = entityBuilder()
                .view(rect)
                .with("rect", rect)
                .with(new ColorChangingComponent())
                .buildAndAttach();

        bg.xProperty().bind(getGameScene().getViewport().xProperty());
        bg.yProperty().bind(getGameScene().getViewport().yProperty());
    }

    private void initPlayer(){
        playerComponent = new PlayerComponent();

        Entity player = entityBuilder().at(100,100)
                .type(PLAYER)
                .bbox(new HitBox(BoundingShape.box(70,60)))
                .view(texture("plane.jpeg").toAnimatedTexture(2, Duration.seconds(0.5)).loop())
                .collidable()
                .with(playerComponent, new WallBuildingComponent())
                .build();

        getGameScene().getViewport().setBounds(0,0, Integer.MAX_VALUE, getAppHeight());
        getGameScene().getViewport().bindToEntity(player, getAppWidth()/3, getAppHeight()/2);

        spawnWithScale(player, Duration.seconds(0.86), Interpolators.BOUNCE.EASE_OUT());
    }

    public void requestNewGame(){
        requestNewGame = true;
    }


    private void showGameOver(){
        showMessage("Game Over !", getGameController()::exit);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
