package com.catproject.trial;

public enum EntityType {
    PLAYER, WALL;
}
