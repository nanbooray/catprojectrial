module flappyplanetrial {
    requires com.almasb.fxgl.all;
    requires javafx.controls;
    requires javafx.graphics;


//    opens com.catproject.trial to javafx.fxml;
    exports com.catproject.trial to com.almasb.fxgl.core;
}